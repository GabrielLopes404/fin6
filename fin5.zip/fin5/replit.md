# LUCREI - Sistema de Gestão Financeira SaaS

## Overview
LUCREI is a comprehensive SaaS financial management system designed for small and medium-sized businesses. It centralizes financial operations through robust management of organizations, clients, invoices, transactions, categories, cost centers, documents, and tags. The platform also offers OFX imports, diverse export options, and detailed financial reports. The project's vision is to provide a modern, responsive, and intuitive platform that enhances business efficiency and offers a standardized user experience.

## Recent Changes (November 10, 2025)
- **🔐 Complete Admin/Owner Management System**: Comprehensive RBAC implementation with granular permissions
- **📊 Admin Dashboard**: Beautiful admin interface with statistics, user management, and audit logs
- **🔍 Immutable Audit Logging**: Complete activity tracking for LGPD/GDPR compliance
- **👥 Advanced User Management**: Suspend, delete (soft), export user data, role management
- **🛡️ Granular Permissions System**: Resource-based permissions with expiration and user-specific grants
- **📋 LGPD/GDPR Compliance**: Data export, consent tracking, data deletion with retention
- **🎨 Admin Interface**: Three new admin pages matching system design (Dashboard, Users, Audit Logs)
- **Enhanced Authentication System**: Complete redesign of login and registration pages with professional UI/UX
- **PF/PJ Support**: Added support for both Pessoa Física (PF) and Pessoa Jurídica (PJ) registration with document validation (CPF/CNPJ)
- **Improved Data Model**: Added `personType` field to organizations and customers tables
- **Landing Page Navigation**: Fixed all footer links to properly navigate to Terms, Privacy, Security, and LGPD pages
- **Export Functionality**: All export features working correctly (Dashboard, Reports, Import History)
- **Settings Page Enhancements**: Added functional theme switcher (light/dark/system) and notification preferences
- **Blog Page**: Fixed title truncation issues with responsive text sizing
- **Security Enhancements**: Maintained CSRF protection, rate limiting, and secure password hashing
- **Deployment Configuration**: Configured VM deployment for production-ready deployment

## 🔐 Sistema de Acesso Administrativo Completo

### Níveis de Permissão e Funções Administrativas

O sistema possui múltiplos níveis de acesso baseados em RBAC (Role-Based Access Control):

#### **Funções Principais:**

1. **OWNER (Proprietário)**
   - Primeiro usuário criado ao registrar uma organização
   - Controle total sobre a organização
   - Pode gerenciar todos os usuários e atribuir qualquer função administrativa
   - Único que pode deletar a organização ou transferir ownership
   - Acesso a todas as funcionalidades do sistema
   
2. **ADMIN (Administrador)**
   - Permissões administrativas amplas
   - Pode gerenciar usuários, transações, relatórios
   - Pode convidar novos usuários e remover usuários existentes
   - Não pode alterar configurações críticas da organização
   
3. **CUSTOMER (Cliente/Usuário)**
   - Permissões limitadas
   - Pode gerenciar apenas suas próprias transações
   - Visualização de relatórios pessoais
   - Não tem acesso a funções administrativas

#### **Funções Administrativas Especializadas:**

1. **admin_full** - Administrador Completo
   - Todas as permissões administrativas exceto gerenciamento de permissões
   - Pode gerenciar usuários, visualizar logs, exportar dados
   
2. **admin_readonly** - Administrador Somente Leitura
   - Visualização de dados administrativos sem permissões de modificação
   - Ideal para auditoria e relatórios
   
3. **auditor** - Auditor
   - Acesso especializado a logs de auditoria
   - Pode verificar integridade da cadeia de auditoria
   - Não pode modificar dados
   
4. **support** - Suporte
   - Pode visualizar dados de usuários
   - Não pode modificar ou deletar

### Endpoints da API Admin

#### **Gerenciamento de Usuários:**
- `GET /api/admin/users` - Listar usuários com filtros e paginação
- `GET /api/admin/users/:userId` - Detalhes de um usuário
- `POST /api/admin/users/:userId/suspend` - Suspender/reativar usuário
- `DELETE /api/admin/users/:userId` - Soft delete de usuário
- `POST /api/admin/users/:userId/role` - Atribuir função administrativa
- `DELETE /api/admin/users/:userId/role` - Remover função administrativa

#### **Logs de Auditoria:**
- `GET /api/admin/audit-logs` - Logs de auditoria com filtros
- `GET /api/admin/audit-logs/verify` - Verificar integridade da cadeia de auditoria

#### **Permissões:**
- `GET /api/admin/permissions` - Listar todas as permissões
- `GET /api/admin/role-permissions/:role` - Permissões de uma função
- `POST /api/admin/users/:userId/permissions` - Conceder permissão específica
- `DELETE /api/admin/user-permissions/:permissionId` - Revogar permissão

#### **Estatísticas:**
- `GET /api/admin/stats` - Estatísticas do sistema (total de usuários, suspensões, etc.)

#### **Exportações e LGPD:**
- `GET /api/admin/export/users` - Exportar lista de usuários (CSV)
- `GET /api/admin/export/audit-logs` - Exportar logs de auditoria (CSV)
- `POST /api/admin/users/:userId/export-data` - Exportar todos os dados de um usuário (LGPD)
- `POST /api/admin/users/:userId/consent` - Registrar consentimento de dados

### Interface Administrativa

#### **Páginas Admin:**
1. **/admin** - Dashboard com estatísticas e visão geral
2. **/admin/users** - Gerenciamento completo de usuários
3. **/admin/audit** - Visualização de logs de auditoria

### Sistema de Auditoria Imutável

Todos os logs de auditoria são **imutáveis** e incluem:
- ID do ator, email, função
- Ação realizada
- Alvo da ação (se aplicável)
- Timestamp, IP, User Agent
- Hash criptográfico da entrada anterior (blockchain-style)
- Metadados adicionais

**Ações Auditadas:**
- Login/Logout de usuários
- Criação, atualização, suspensão, deleção de usuários
- Concessão/revogação de permissões
- Exportação de dados
- Visualização de dados sensíveis

### Credenciais de Teste

**Usuários administrativos de teste criados:**

1. **Owner/Proprietário:**
   - Email: `owner@lucrei.com.br`
   - Senha: `Owner@2025`
   - Função: OWNER
   
2. **Administrador Completo:**
   - Email: `admin@lucrei.com.br`
   - Senha: `Admin@2025`
   - Função: ADMIN (admin_full)
   
3. **Administrador Somente Leitura:**
   - Email: `readonly@lucrei.com.br`
   - Senha: `Readonly@2025`
   - Função: ADMIN (admin_readonly)
   
4. **Auditor:**
   - Email: `auditor@lucrei.com.br`
   - Senha: `Auditor@2025`
   - Função: ADMIN (auditor)
   
5. **Suporte:**
   - Email: `support@lucrei.com.br`
   - Senha: `Support@2025`
   - Função: ADMIN (support)

6. **Cliente/Usuário Normal:**
   - Email: `customer@lucrei.com.br`
   - Senha: `Customer@2025`
   - Função: CUSTOMER

### Segurança e Compliance

- **Criptografia:** Senhas com bcrypt (12 rounds)
- **Sessões:** Armazenadas no PostgreSQL com regeneração após login
- **CSRF Protection:** Ativo em todas as rotas modificadoras
- **Rate Limiting:** Proteção contra ataques de força bruta
- **Isolamento de Dados:** Queries filtradas por `organizationId`
- **Auditoria:** Logs imutáveis de todas as ações administrativas
- **LGPD/GDPR:** Exportação e deleção de dados de usuários
- **Soft Delete:** Usuários deletados mantidos para auditoria
- **Consentimento:** Sistema de rastreamento de consentimento de dados

## User Preferences
- I prefer simple language and clear explanations.
- I want iterative development with frequent updates and feedback loops.
- Ask before making major changes to the core architecture or existing functionalities.
- Ensure all new features align with the established design system and visual patterns.
- Prioritize security and data integrity in all implementations.
- Do not make changes to the file `design_guidelines.md`.

## System Architecture
LUCREI employs a client-server architecture, utilizing **React 18** (Vite) for the frontend and **Express.js** (Node.js 20) for the backend, with **TypeScript** implemented across the full stack for type safety.

### UI/UX Decisions
The system features a modern, responsive, and user-friendly design.
- **Consistent Design System:** Adherence to a modern visual standard using `shadcn/ui` components.
- **Theming:** Supports dark/light themes via `next-themes`.
- **Animations:** Smooth transitions and micro-interactions powered by `Framer Motion`.
- **Visuals:** Incorporates gradients in titles, colored cards with shadows, gradient-backed Lucide React icons, and colored badges.
- **Data Visualization:** Interactive charts and graphs are rendered using `Recharts`.
- **Mobile Responsiveness:** Includes fluid typography, touch-optimized effects, horizontal table scrolling, and responsive image handling.

### Technical Implementations
- **Backend:**
    - **Database:** PostgreSQL managed with `Drizzle ORM`. Session storage uses PostgreSQL via `connect-pg-simple`.
    - **API:** RESTful API for CRUD operations across all entities (Organizations, Users, Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Bank Accounts, Reconciliations, User Preferences, Subscriptions). Includes endpoints for metrics, activity logs, financial reports (DRE, Cash Flow, Statement), and data exports.
    - **Authentication:** Session-based via `Passport.js` and `express-session`, with `bcryptjs` (12 rounds) for password hashing. Features password reset, email verification, and session regeneration for security.
    - **Authorization:** Role-based access control (OWNER, ADMIN, CUSTOMER) and organization-level data isolation.
    - **Validation:** Server-side data validation enforced with `Zod` schemas.
    - **Security:** `Helmet` for HTTP headers, CORS, `express-rate-limit`, and global CSRF protection.
    - **Exports:** XLSX and CSV generation using `xlsx` and `json2csv`.
    - **CSV Import:** Comprehensive CSV parsing, validation, and bulk transaction creation.
    - **File Uploads:** `Multer` handles secure file uploads with MIME validation and size limits.
    - **Bank Account Management:** Automatic balance recalculation upon transaction modifications.
    - **Monitoring & Logging:** `Sentry` for error tracking and `Winston` for structured logging.
    - **Email Service:** `Resend` integration for HTML email notifications.
    - **OFX Parser:** Financial file parsing and matching.
    - **PDF Export:** Generation of DRE, Cash Flow, Statement, and Invoice PDFs using `PDFKit`.
    - **Caching:** Memoization with TTL.
- **Frontend:**
    - **State Management & Data Fetching:** `TanStack Query (React Query)` for data operations.
    - **Routing:** Light-weight client-side routing with `Wouter`.
    - **Form Management:** `React Hook Form` integrated with `Zod` for client-side validation.
    - **Error Handling:** Root and route-level error boundaries.
    - **Loading States:** Uses spinners, skeletons, and progress indicators.
    - **Accessibility:** Ensured through Radix UI components.
    - **Code Splitting:** Implemented with lazy loading.

### Feature Specifications
- **Core Modules:** Management of Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Bank Accounts, Reconciliations, User Preferences, and Subscriptions.
- **Dashboard:** Provides key metrics, interactive charts, and recent activities.
- **Financial Transactions:** Comprehensive management with categorization, bank linking, cost center allocation, tags, and document attachments.
- **Reporting:** Real-time financial reports including DRE, Cash Flow, and Statement.
- **Data Operations:** Supports Excel, CSV, and JSON exports; OFX reconciliation.
- **Settings:** User profiles, preferences (theme, language, notifications), and organization management.

### System Design Choices
- **Modularity:** Structured project separating client, server, and shared code.
- **Scalability:** Designed with future growth in mind.
- **Observability:** Focus on logging and monitoring for production with Sentry and Winston.
- **Deployment:** Configured for automated, autoscale deployment.

## External Dependencies
- **Stripe:** For payment processing and subscription management.
- **Resend:** Email service for notifications and transactional emails.
- **PostgreSQL:** Primary relational database.
- **connect-pg-simple:** PostgreSQL session store.
- **Passport.js:** Authentication middleware.
- **bcryptjs:** Password hashing library.
- **Zod:** Schema validation library.
- **xlsx:** Excel file generation.
- **json2csv:** CSV file generation and parsing.
- **csv-parse:** CSV parsing for imports.
- **PDFKit:** PDF generation library.
- **Multer:** Middleware for handling `multipart/form-data`.
- **Recharts:** Charting library for React.
- **Lucide React:** Icon library.
- **Framer Motion:** Animation library.
- **TanStack Query (React Query):** Data fetching and state management.
- **shadcn/ui:** UI component library.
- **Tailwind CSS:** Utility-first CSS framework.
- **Vite:** Frontend build tool.
- **Sentry:** Error tracking and performance monitoring (optional).
- **Winston:** Logging library.