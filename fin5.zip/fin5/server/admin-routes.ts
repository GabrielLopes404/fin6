import { Router, type Request, type Response } from "express";
import { db } from "./db";
import { users, auditLogs, dataExportRequests, dataDeletionRequests, systemAlerts, permissions as permissionsTable, rolePermissions, userPermissions } from "@shared/schema";
import { eq, desc, and, or, like, sql, isNull, isNotNull } from "drizzle-orm";
import { createAuditLog, getClientIp, verifyAuditLogChain } from "./audit-logger";
import { requireOwner, requireAdminOrOwner, requirePermission, hasPermission, clearPermissionCache } from "./rbac";
import bcrypt from "bcryptjs";
import crypto from "crypto";

export const adminRouter = Router();

// ===== USER MANAGEMENT ENDPOINTS =====

// Get all users (with filters)
adminRouter.get("/users", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { 
      search, 
      role, 
      suspended, 
      deleted, 
      page = 1, 
      limit = 50 
    } = req.query;

    const currentUser = req.user!;
    const offset = (Number(page) - 1) * Number(limit);

    let query = db.select({
      id: users.id,
      username: users.username,
      email: users.email,
      name: users.name,
      avatar: users.avatar,
      role: users.role,
      adminRole: users.adminRole,
      emailVerified: users.emailVerified,
      isSuspended: users.isSuspended,
      suspendedAt: users.suspendedAt,
      suspensionReason: users.suspensionReason,
      deletedAt: users.deletedAt,
      lastLoginAt: users.lastLoginAt,
      lastLoginIp: users.lastLoginIp,
      twoFactorEnabled: users.twoFactorEnabled,
      consentGiven: users.consentGiven,
      createdAt: users.createdAt,
    }).from(users);

    const conditions = [];

    if (search) {
      conditions.push(
        or(
          like(users.email, `%${search}%`),
          like(users.name, `%${search}%`),
          like(users.username, `%${search}%`)
        )
      );
    }

    if (role) {
      conditions.push(eq(users.role, role as "OWNER" | "ADMIN" | "CUSTOMER"));
    }

    if (suspended === 'true') {
      conditions.push(eq(users.isSuspended, true));
    } else if (suspended === 'false') {
      conditions.push(eq(users.isSuspended, false));
    }

    if (deleted === 'true') {
      conditions.push(isNotNull(users.deletedAt));
    } else if (deleted === 'false' || !deleted) {
      conditions.push(isNull(users.deletedAt));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions as [any, ...any[]])) as any;
    }

    const results = await query.orderBy(desc(users.createdAt)).limit(Number(limit)).offset(offset);

    // Count total for pagination
    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(conditions.length > 0 ? and(...conditions as [any, ...any[]]) : undefined);

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "user_view",
      actionDetails: { count: results.length, filters: { search, role, suspended, deleted } },
      success: true,
    });

    res.json({
      users: results,
      pagination: {
        total: count,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(count / Number(limit)),
      },
    });
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ message: "Failed to fetch users" });
  }
});

// Get single user details
adminRouter.get("/users/:userId", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const currentUser = req.user!;

    const [user] = await db.select().from(users).where(eq(users.id, userId));

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Remove sensitive fields
    const { password, resetToken, resetTokenExpiry, twoFactorSecret, verificationToken, ...safeUser } = user;

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      targetEmail: user.email,
      action: "user_view",
      actionDetails: { viewedFields: Object.keys(safeUser) },
      success: true,
    });

    res.json(safeUser);
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ message: "Failed to fetch user" });
  }
});

// Suspend/Unsuspend user
adminRouter.post("/users/:userId/suspend", requirePermission("users", "suspend"), async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const { suspend, reason } = req.body;
    const currentUser = req.user!;

    const [targetUser] = await db.select().from(users).where(eq(users.id, userId));

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Can't suspend owner
    if (targetUser.role === 'OWNER') {
      return res.status(403).json({ message: "Cannot suspend owner user" });
    }

    await db.update(users)
      .set({
        isSuspended: suspend,
        suspendedAt: suspend ? new Date() : null,
        suspendedBy: suspend ? (currentUser as any).id : null,
        suspensionReason: suspend ? reason : null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      targetEmail: targetUser.email,
      action: suspend ? "user_suspend" : "user_restore",
      reason,
      actionDetails: { suspend, reason },
      success: true,
    });

    res.json({ message: suspend ? "User suspended successfully" : "User unsuspended successfully" });
  } catch (error) {
    console.error("Error suspending user:", error);
    res.status(500).json({ message: "Failed to update user suspension status" });
  }
});

// Update user role (Owner only)
adminRouter.put("/users/:userId/role", requireOwner, async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const { role, adminRole } = req.body;
    const currentUser = req.user!;

    const [targetUser] = await db.select().from(users).where(eq(users.id, userId));

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    await db.update(users)
      .set({
        role,
        adminRole: role === 'ADMIN' ? adminRole : null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    clearPermissionCache(userId);

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      targetEmail: targetUser.email,
      action: "role_assigned",
      actionDetails: { oldRole: targetUser.role, newRole: role, adminRole },
      success: true,
    });

    res.json({ message: "User role updated successfully" });
  } catch (error) {
    console.error("Error updating user role:", error);
    res.status(500).json({ message: "Failed to update user role" });
  }
});

// Soft delete user
adminRouter.delete("/users/:userId", requirePermission("users", "delete"), async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const { reason } = req.body;
    const currentUser = req.user!;

    const [targetUser] = await db.select().from(users).where(eq(users.id, userId));

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Can't delete owner
    if (targetUser.role === 'OWNER') {
      return res.status(403).json({ message: "Cannot delete owner user" });
    }

    // Soft delete (mark as deleted with 30 day retention)
    const scheduledDeletion = new Date();
    scheduledDeletion.setDate(scheduledDeletion.getDate() + 30);

    await db.update(users)
      .set({
        deletedAt: new Date(),
        deletedBy: (currentUser as any).id,
        deletionReason: reason,
        scheduledDeletionDate: scheduledDeletion,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      targetEmail: targetUser.email,
      action: "user_deleted",
      reason,
      actionDetails: { deletionType: "soft", scheduledDeletion },
      success: true,
    });

    res.json({ 
      message: "User soft deleted successfully",
      scheduledDeletionDate: scheduledDeletion,
    });
  } catch (error) {
    console.error("Error deleting user:", error);
    res.status(500).json({ message: "Failed to delete user" });
  }
});

// ===== AUDIT LOG ENDPOINTS =====

// Get audit logs
adminRouter.get("/audit-logs", requirePermission("audit_logs", "view"), async (req: Request, res: Response) => {
  try {
    const { 
      actorId, 
      targetId, 
      action, 
      startDate, 
      endDate,
      page = 1, 
      limit = 100 
    } = req.query;

    const currentUser = req.user!;
    const offset = (Number(page) - 1) * Number(limit);

    let query = db.select().from(auditLogs);
    const conditions = [];

    if (actorId) {
      conditions.push(eq(auditLogs.actorId, actorId as string));
    }

    if (targetId) {
      conditions.push(eq(auditLogs.targetId, targetId as string));
    }

    if (action) {
      conditions.push(eq(auditLogs.action, action as any));
    }

    if (startDate) {
      conditions.push(sql`${auditLogs.createdAt} >= ${new Date(startDate as string)}`);
    }

    if (endDate) {
      conditions.push(sql`${auditLogs.createdAt} <= ${new Date(endDate as string)}`);
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions as [any, ...any[]])) as any;
    }

    const logs = await query.orderBy(desc(auditLogs.createdAt)).limit(Number(limit)).offset(offset);

    // Count total
    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` })
      .from(auditLogs)
      .where(conditions.length > 0 ? and(...conditions as [any, ...any[]]) : undefined);

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "user_view",
      targetType: "audit_logs",
      actionDetails: { count: logs.length, filters: { actorId, targetId, action, startDate, endDate } },
      success: true,
    });

    res.json({
      logs,
      pagination: {
        total: count,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(count / Number(limit)),
      },
    });
  } catch (error) {
    console.error("Error fetching audit logs:", error);
    res.status(500).json({ message: "Failed to fetch audit logs" });
  }
});

// Verify audit log chain integrity
adminRouter.get("/audit-logs/verify", requireOwner, async (req: Request, res: Response) => {
  try {
    const { limit = 1000 } = req.query;
    const result = await verifyAuditLogChain(Number(limit));

    await createAuditLog({
      actorId: (req.user as any).id,
      actorRole: (req.user as any).role,
      actorEmail: (req.user as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "user_view",
      targetType: "audit_logs",
      actionDetails: { verificationResult: result },
      success: true,
    });

    res.json(result);
  } catch (error) {
    console.error("Error verifying audit logs:", error);
    res.status(500).json({ message: "Failed to verify audit logs" });
  }
});

// ===== PERMISSIONS MANAGEMENT =====

// Get all permissions
adminRouter.get("/permissions", requirePermission("permissions", "view"), async (req: Request, res: Response) => {
  try {
    const allPermissions = await db.select().from(permissionsTable).orderBy(permissionsTable.resource, permissionsTable.action);
    res.json(allPermissions);
  } catch (error) {
    console.error("Error fetching permissions:", error);
    res.status(500).json({ message: "Failed to fetch permissions" });
  }
});

// Get role permissions
adminRouter.get("/role-permissions/:role", requirePermission("permissions", "view"), async (req: Request, res: Response) => {
  try {
    const { role } = req.params;

    const rolePerms = await db
      .select({ permission: permissionsTable })
      .from(rolePermissions)
      .innerJoin(permissionsTable, eq(rolePermissions.permissionId, permissionsTable.id))
      .where(eq(rolePermissions.role, role));

    res.json(rolePerms.map(rp => rp.permission));
  } catch (error) {
    console.error("Error fetching role permissions:", error);
    res.status(500).json({ message: "Failed to fetch role permissions" });
  }
});

// Grant permission to user (Owner only)
adminRouter.post("/users/:userId/permissions", requireOwner, async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const { permissionId, reason, expiresAt } = req.body;
    const currentUser = req.user!;

    await db.insert(userPermissions).values({
      userId,
      permissionId,
      grantedBy: (currentUser as any).id,
      reason,
      expiresAt: expiresAt ? new Date(expiresAt) : null,
    });

    clearPermissionCache(userId);

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      action: "permission_granted",
      reason,
      actionDetails: { permissionId, expiresAt },
      success: true,
    });

    res.json({ message: "Permission granted successfully" });
  } catch (error) {
    console.error("Error granting permission:", error);
    res.status(500).json({ message: "Failed to grant permission" });
  }
});

// ===== SYSTEM ALERTS =====

// Get system alerts
adminRouter.get("/alerts", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { resolved = 'false' } = req.query;

    const alerts = await db
      .select()
      .from(systemAlerts)
      .where(eq(systemAlerts.resolved, resolved === 'true'))
      .orderBy(desc(systemAlerts.createdAt))
      .limit(100);

    res.json(alerts);
  } catch (error) {
    console.error("Error fetching alerts:", error);
    res.status(500).json({ message: "Failed to fetch alerts" });
  }
});

// Resolve alert
adminRouter.post("/alerts/:alertId/resolve", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { alertId } = req.params;
    const currentUser = req.user!;

    await db.update(systemAlerts)
      .set({
        resolved: true,
        resolvedBy: (currentUser as any).id,
        resolvedAt: new Date(),
      })
      .where(eq(systemAlerts.id, alertId));

    res.json({ message: "Alert resolved successfully" });
  } catch (error) {
    console.error("Error resolving alert:", error);
    res.status(500).json({ message: "Failed to resolve alert" });
  }
});

// ===== DATA EXPORT REQUESTS =====

// Get export requests
adminRouter.get("/export-requests", requirePermission("data_export", "approve"), async (req: Request, res: Response) => {
  try {
    const requests = await db
      .select()
      .from(dataExportRequests)
      .orderBy(desc(dataExportRequests.createdAt))
      .limit(100);

    res.json(requests);
  } catch (error) {
    console.error("Error fetching export requests:", error);
    res.status(500).json({ message: "Failed to fetch export requests" });
  }
});

// Approve export request
adminRouter.post("/export-requests/:requestId/approve", requirePermission("data_export", "approve"), async (req: Request, res: Response) => {
  try {
    const { requestId } = req.params;
    const currentUser = req.user!;

    await db.update(dataExportRequests)
      .set({
        status: "approved",
        approvedBy: (currentUser as any).id,
        approvedAt: new Date(),
      })
      .where(eq(dataExportRequests.id, requestId));

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: requestId,
      targetType: "export_request",
      action: "data_exported",
      success: true,
    });

    res.json({ message: "Export request approved successfully" });
  } catch (error) {
    console.error("Error approving export request:", error);
    res.status(500).json({ message: "Failed to approve export request" });
  }
});

// ===== DATA DELETION REQUESTS =====

// Get deletion requests
adminRouter.get("/deletion-requests", requireOwner, async (req: Request, res: Response) => {
  try {
    const requests = await db
      .select()
      .from(dataDeletionRequests)
      .orderBy(desc(dataDeletionRequests.createdAt))
      .limit(100);

    res.json(requests);
  } catch (error) {
    console.error("Error fetching deletion requests:", error);
    res.status(500).json({ message: "Failed to fetch deletion requests" });
  }
});

// Approve deletion request
adminRouter.post("/deletion-requests/:requestId/approve", requireOwner, async (req: Request, res: Response) => {
  try {
    const { requestId } = req.params;
    const currentUser = req.user!;

    await db.update(dataDeletionRequests)
      .set({
        status: "approved",
        approvedBy: (currentUser as any).id,
        approvedAt: new Date(),
      })
      .where(eq(dataDeletionRequests.id, requestId));

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: requestId,
      targetType: "deletion_request",
      action: "data_deleted",
      success: true,
    });

    res.json({ message: "Deletion request approved successfully" });
  } catch (error) {
    console.error("Error approving deletion request:", error);
    res.status(500).json({ message: "Failed to approve deletion request" });
  }
});

// ===== STATISTICS =====

// Get admin dashboard stats
adminRouter.get("/stats", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const [totalUsers] = await db.select({ count: sql<number>`count(*)::int` }).from(users);
    const [activeUsers] = await db.select({ count: sql<number>`count(*)::int` }).from(users).where(and(isNull(users.deletedAt), eq(users.isSuspended, false)));
    const [suspendedUsers] = await db.select({ count: sql<number>`count(*)::int` }).from(users).where(eq(users.isSuspended, true));
    const [deletedUsers] = await db.select({ count: sql<number>`count(*)::int` }).from(users).where(isNotNull(users.deletedAt));
    
    const [totalAuditLogs] = await db.select({ count: sql<number>`count(*)::int` }).from(auditLogs);
    const [todayLogs] = await db.select({ count: sql<number>`count(*)::int` }).from(auditLogs).where(sql`${auditLogs.createdAt} >= CURRENT_DATE`);
    
    const [pendingExports] = await db.select({ count: sql<number>`count(*)::int` }).from(dataExportRequests).where(eq(dataExportRequests.status, "pending"));
    const [pendingDeletions] = await db.select({ count: sql<number>`count(*)::int` }).from(dataDeletionRequests).where(eq(dataDeletionRequests.status, "pending"));
    
    const [unresolvedAlerts] = await db.select({ count: sql<number>`count(*)::int` }).from(systemAlerts).where(eq(systemAlerts.resolved, false));

    res.json({
      users: {
        total: totalUsers.count,
        active: activeUsers.count,
        suspended: suspendedUsers.count,
        deleted: deletedUsers.count,
      },
      auditLogs: {
        total: totalAuditLogs.count,
        today: todayLogs.count,
      },
      requests: {
        pendingExports: pendingExports.count,
        pendingDeletions: pendingDeletions.count,
      },
      alerts: {
        unresolved: unresolvedAlerts.count,
      },
    });
  } catch (error) {
    console.error("Error fetching stats:", error);
    res.status(500).json({ message: "Failed to fetch statistics" });
  }
});
