import { UAParser } from 'ua-parser-js';
import { db } from './db';
import { sql } from 'drizzle-orm';

export interface ActiveSession {
  sid: string;
  userId: string;
  ipAddress: string;
  userAgent: string;
  device: string;
  browser: string;
  os: string;
  lastActivity: Date;
  current: boolean;
}

export async function getActiveSessions(userId: string, currentSessionId?: string): Promise<ActiveSession[]> {
  try {
    const result = await db.execute(sql`
      SELECT 
        sid,
        sess::json->>'userId' as user_id,
        sess::json->'cookie'->>'ipAddress' as ip_address,
        sess::json->'cookie'->>'userAgent' as user_agent,
        expire
      FROM session
      WHERE sess::json->>'userId' = ${userId}
      AND expire > NOW()
      ORDER BY expire DESC
    `);

    const sessions: ActiveSession[] = result.rows.map((row: any) => {
      const parser = new UAParser(row.user_agent || '');
      const parsedUA = parser.getResult();

      return {
        sid: row.sid,
        userId: row.user_id,
        ipAddress: row.ip_address || 'Desconhecido',
        userAgent: row.user_agent || 'Desconhecido',
        device: parsedUA.device.model || parsedUA.device.type || 'Desktop',
        browser: `${parsedUA.browser.name || 'Desconhecido'} ${parsedUA.browser.version || ''}`.trim(),
        os: `${parsedUA.os.name || 'Desconhecido'} ${parsedUA.os.version || ''}`.trim(),
        lastActivity: new Date(row.expire),
        current: row.sid === currentSessionId
      };
    });

    return sessions;
  } catch (error) {
    return [];
  }
}

export async function revokeSession(sessionId: string, userId: string): Promise<boolean> {
  try {
    await db.execute(sql`
      DELETE FROM session
      WHERE sid = ${sessionId}
      AND sess::json->>'userId' = ${userId}
    `);
    return true;
  } catch (error) {
    return false;
  }
}
