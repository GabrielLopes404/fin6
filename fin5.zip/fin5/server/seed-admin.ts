import { db, pool } from "./db";
import { users, organizations } from "@shared/schema";
import bcrypt from "bcryptjs";
import { initializeDefaultPermissions } from "./rbac";

export async function seedAdminUsers() {
  try {
    console.log('Starting admin user seeding...');

    // Initialize default permissions first
    await initializeDefaultPermissions();

    // Check if users already exist
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length > 0) {
      console.log('Users already exist, skipping seed');
      return;
    }

    // Create default organization
    const [org] = await db.insert(organizations).values({
      name: "LUCREI Platform",
      email: "contato@lucrei.com.br",
      planType: "enterprise",
    }).returning();

    console.log('Organization created:', org.id);

    // Create Owner user
    const ownerPassword = await bcrypt.hash("Owner@2025", 10);
    const [owner] = await db.insert(users).values({
      organizationId: org.id,
      username: "owner",
      email: "owner@lucrei.com.br",
      password: ownerPassword,
      name: "Platform Owner",
      role: "OWNER",
      emailVerified: true,
      consentGiven: true,
      consentTimestamp: new Date(),
      twoFactorEnabled: false,
      twoFactorRequiredForRole: true,
    }).returning();

    console.log('Owner user created:', owner.email);

    // Create Admin (full) user
    const adminPassword = await bcrypt.hash("Admin@2025", 10);
    const [admin] = await db.insert(users).values({
      organizationId: org.id,
      username: "admin",
      email: "admin@lucrei.com.br",
      password: adminPassword,
      name: "System Admin",
      role: "ADMIN",
      adminRole: "admin_full",
      emailVerified: true,
      consentGiven: true,
      consentTimestamp: new Date(),
      twoFactorEnabled: false,
      twoFactorRequiredForRole: true,
    }).returning();

    console.log('Admin user created:', admin.email);

    // Create Read-only Admin
    const readonlyPassword = await bcrypt.hash("Readonly@2025", 10);
    const [readonly] = await db.insert(users).values({
      organizationId: org.id,
      username: "readonly",
      email: "readonly@lucrei.com.br",
      password: readonlyPassword,
      name: "Read-only Admin",
      role: "ADMIN",
      adminRole: "admin_readonly",
      emailVerified: true,
      consentGiven: true,
      consentTimestamp: new Date(),
      twoFactorEnabled: false,
    }).returning();

    console.log('Read-only admin user created:', readonly.email);

    // Create Auditor
    const auditorPassword = await bcrypt.hash("Auditor@2025", 10);
    const [auditor] = await db.insert(users).values({
      organizationId: org.id,
      username: "auditor",
      email: "auditor@lucrei.com.br",
      password: auditorPassword,
      name: "System Auditor",
      role: "ADMIN",
      adminRole: "auditor",
      emailVerified: true,
      consentGiven: true,
      consentTimestamp: new Date(),
      twoFactorEnabled: false,
    }).returning();

    console.log('Auditor user created:', auditor.email);

    // Create Support user
    const supportPassword = await bcrypt.hash("Support@2025", 10);
    const [support] = await db.insert(users).values({
      organizationId: org.id,
      username: "support",
      email: "support@lucrei.com.br",
      password: supportPassword,
      name: "Support Agent",
      role: "ADMIN",
      adminRole: "support",
      emailVerified: true,
      consentGiven: true,
      consentTimestamp: new Date(),
      twoFactorEnabled: false,
    }).returning();

    console.log('Support user created:', support.email);

    // Create test customer users
    const customerPassword = await bcrypt.hash("Customer@2025", 10);
    const [customer1] = await db.insert(users).values({
      organizationId: org.id,
      username: "joao.silva",
      email: "joao.silva@cliente.com.br",
      password: customerPassword,
      name: "João Silva",
      role: "CUSTOMER",
      emailVerified: true,
      consentGiven: true,
      consentTimestamp: new Date(),
    }).returning();

    const [customer2] = await db.insert(users).values({
      organizationId: org.id,
      username: "maria.santos",
      email: "maria.santos@cliente.com.br",
      password: customerPassword,
      name: "Maria Santos",
      role: "CUSTOMER",
      emailVerified: true,
      consentGiven: true,
      consentTimestamp: new Date(),
    }).returning();

    console.log('Test customer users created');

    console.log('\n========================================');
    console.log('SEED COMPLETED SUCCESSFULLY!');
    console.log('========================================\n');
    console.log('CREDENTIAL FOR TESTING:\n');
    console.log('OWNER (Full Platform Control):');
    console.log('  Email: owner@lucrei.com.br');
    console.log('  Password: Owner@2025\n');
    console.log('ADMIN (Full Admin Access):');
    console.log('  Email: admin@lucrei.com.br');
    console.log('  Password: Admin@2025\n');
    console.log('READ-ONLY ADMIN (View Only):');
    console.log('  Email: readonly@lucrei.com.br');
    console.log('  Password: Readonly@2025\n');
    console.log('AUDITOR (Audit & Logs):');
    console.log('  Email: auditor@lucrei.com.br');
    console.log('  Password: Auditor@2025\n');
    console.log('SUPPORT (User Support):');
    console.log('  Email: support@lucrei.com.br');
    console.log('  Password: Support@2025\n');
    console.log('TEST CUSTOMER:');
    console.log('  Email: joao.silva@cliente.com.br');
    console.log('  Password: Customer@2025');
    console.log('========================================\n');

    return {
      owner,
      admin,
      readonly,
      auditor,
      support,
      customer1,
      customer2,
    };
  } catch (error) {
    console.error('Error seeding admin users:', error);
    throw error;
  }
}

// Run seed if called directly
import { fileURLToPath } from 'url';
if (import.meta.url.startsWith('file:')) {
  const modulePath = fileURLToPath(import.meta.url);
  if (process.argv[1] === modulePath) {
    seedAdminUsers()
      .then(() => {
        console.log('Seed script completed');
        process.exit(0);
      })
      .catch((error) => {
        console.error('Seed script failed:', error);
        process.exit(1);
      });
  }
}
