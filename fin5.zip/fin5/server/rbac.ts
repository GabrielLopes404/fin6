import { Request, Response, NextFunction } from "express";
import { db } from "./db";
import { permissions, rolePermissions, userPermissions, users } from "@shared/schema";
import { eq, and, or, sql } from "drizzle-orm";
import { createAuditLog, getClientIp } from "./audit-logger";

// Permission cache (in-memory cache for performance)
const permissionCache = new Map<string, Set<string>>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes
let lastCacheUpdate = 0;

// Helper to get user's permissions
export async function getUserPermissions(userId: string, userRole: string, adminRole?: string | null): Promise<Set<string>> {
  const cacheKey = `${userId}-${userRole}-${adminRole || ''}`;
  const now = Date.now();
  
  // Check cache
  if (permissionCache.has(cacheKey) && (now - lastCacheUpdate) < CACHE_TTL) {
    return permissionCache.get(cacheKey)!;
  }

  const userPerms = new Set<string>();

  try {
    // Get role-based permissions
    const roleToCheck = adminRole || userRole;
    const rolePerms = await db
      .select({ permission: permissions })
      .from(rolePermissions)
      .innerJoin(permissions, eq(rolePermissions.permissionId, permissions.id))
      .where(eq(rolePermissions.role, roleToCheck));

    rolePerms.forEach(rp => {
      if (rp.permission) {
        userPerms.add(`${rp.permission.resource}:${rp.permission.action}`);
      }
    });

    // Get user-specific permissions (overrides)
    const userSpecificPerms = await db
      .select({ permission: permissions })
      .from(userPermissions)
      .innerJoin(permissions, eq(userPermissions.permissionId, permissions.id))
      .where(
        and(
          eq(userPermissions.userId, userId),
          sql`${userPermissions.expiresAt} IS NULL OR ${userPermissions.expiresAt} > NOW()`
        )
      );

    userSpecificPerms.forEach(up => {
      if (up.permission) {
        userPerms.add(`${up.permission.resource}:${up.permission.action}`);
      }
    });

    // Update cache
    permissionCache.set(cacheKey, userPerms);
    lastCacheUpdate = now;

    return userPerms;
  } catch (error) {
    console.error('Error fetching user permissions:', error);
    return userPerms;
  }
}

// Check if user has specific permission
export async function hasPermission(
  userId: string, 
  userRole: string, 
  adminRole: string | null | undefined,
  resource: string, 
  action: string
): Promise<boolean> {
  // Owner has all permissions
  if (userRole === 'OWNER') {
    return true;
  }

  const userPerms = await getUserPermissions(userId, userRole, adminRole);
  const permissionKey = `${resource}:${action}`;
  
  return userPerms.has(permissionKey) || userPerms.has(`${resource}:*`) || userPerms.has(`*:${action}`) || userPerms.has('*:*');
}

// Clear permission cache (call this when permissions are updated)
export function clearPermissionCache(userId?: string) {
  if (userId) {
    // Clear specific user's cache
    const keys = Array.from(permissionCache.keys());
    for (const key of keys) {
      if (key.startsWith(userId)) {
        permissionCache.delete(key);
      }
    }
  } else {
    // Clear all cache
    permissionCache.clear();
  }
  lastCacheUpdate = 0;
}

// Middleware factory for permission checking
export function requirePermission(resource: string, action: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated() || !req.user) {
      await createAuditLog({
        action: "user_view",
        targetType: resource,
        actorIp: getClientIp(req),
        actorUserAgent: req.headers['user-agent'],
        success: false,
        errorMessage: "Unauthorized - no user session"
      });
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = req.user as any;
    const allowed = await hasPermission(user.id, user.role, user.adminRole, resource, action);

    if (!allowed) {
      await createAuditLog({
        actorId: user.id,
        actorRole: user.role,
        actorEmail: user.email,
        actorIp: getClientIp(req),
        actorUserAgent: req.headers['user-agent'],
        action: "user_view",
        targetType: resource,
        success: false,
        errorMessage: `Permission denied: ${resource}:${action}`,
        reason: "Insufficient permissions"
      });
      return res.status(403).json({ 
        message: "Forbidden: You don't have permission to perform this action",
        required: `${resource}:${action}`
      });
    }

    next();
  };
}

// Middleware to require Owner role
export function requireOwner(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated() || !req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const user = req.user as any;
  if (user.role !== 'OWNER') {
    createAuditLog({
      actorId: user.id,
      actorRole: user.role,
      actorEmail: user.email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "user_view",
      success: false,
      errorMessage: "Access denied: Owner role required",
      reason: "Non-owner attempted owner-only action"
    });
    return res.status(403).json({ message: "Forbidden: Owner access required" });
  }

  next();
}

// Middleware to require Admin or Owner role
export function requireAdminOrOwner(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated() || !req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const user = req.user as any;
  if (user.role !== 'ADMIN' && user.role !== 'OWNER') {
    createAuditLog({
      actorId: user.id,
      actorRole: user.role,
      actorEmail: user.email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "user_view",
      success: false,
      errorMessage: "Access denied: Admin or Owner role required",
      reason: "Non-admin/owner attempted admin action"
    });
    return res.status(403).json({ message: "Forbidden: Admin or Owner access required" });
  }

  next();
}

// Initialize default permissions in the database
export async function initializeDefaultPermissions() {
  try {
    // Check if permissions already exist
    const existingPerms = await db.select().from(permissions).limit(1);
    if (existingPerms.length > 0) {
      return; // Already initialized
    }

    // Define default permissions
    const defaultPermissions = [
      // User management
      { name: 'view_users', resource: 'users', action: 'view', description: 'View user list and profiles' },
      { name: 'create_users', resource: 'users', action: 'create', description: 'Create new users' },
      { name: 'update_users', resource: 'users', action: 'update', description: 'Update user information' },
      { name: 'delete_users', resource: 'users', action: 'delete', description: 'Delete users' },
      { name: 'export_users', resource: 'users', action: 'export', description: 'Export user data' },
      { name: 'suspend_users', resource: 'users', action: 'suspend', description: 'Suspend/unsuspend users' },
      
      // Permission management
      { name: 'view_permissions', resource: 'permissions', action: 'view', description: 'View permissions' },
      { name: 'manage_permissions', resource: 'permissions', action: 'manage', description: 'Grant/revoke permissions' },
      
      // Audit logs
      { name: 'view_audit_logs', resource: 'audit_logs', action: 'view', description: 'View audit logs' },
      { name: 'export_audit_logs', resource: 'audit_logs', action: 'export', description: 'Export audit logs' },
      
      // Settings
      { name: 'view_settings', resource: 'settings', action: 'view', description: 'View system settings' },
      { name: 'update_settings', resource: 'settings', action: 'update', description: 'Update system settings' },
      
      // Data exports
      { name: 'request_data_export', resource: 'data_export', action: 'request', description: 'Request data exports' },
      { name: 'approve_data_export', resource: 'data_export', action: 'approve', description: 'Approve data export requests' },
      
      // Data deletion
      { name: 'request_data_deletion', resource: 'data_deletion', action: 'request', description: 'Request data deletion' },
      { name: 'approve_data_deletion', resource: 'data_deletion', action: 'approve', description: 'Approve data deletion requests' },
      
      // Transactions (for regular users)
      { name: 'view_transactions', resource: 'transactions', action: 'view', description: 'View transactions' },
      { name: 'create_transactions', resource: 'transactions', action: 'create', description: 'Create transactions' },
      { name: 'update_transactions', resource: 'transactions', action: 'update', description: 'Update transactions' },
      { name: 'delete_transactions', resource: 'transactions', action: 'delete', description: 'Delete transactions' },
    ];

    // Insert permissions
    const insertedPerms = await db.insert(permissions).values(defaultPermissions).returning();
    
    // Create permission map
    const permMap = new Map(insertedPerms.map(p => [p.name, p.id]));

    // Assign permissions to roles
    const rolePermissionsData = [
      // OWNER has all permissions (we'll handle this in code by checking role first)
      
      // ADMIN (full access admin)
      { role: 'ADMIN', permissions: [
        'view_users', 'create_users', 'update_users', 'suspend_users', 'export_users',
        'view_permissions', 'view_audit_logs', 'export_audit_logs',
        'view_settings', 'update_settings',
        'request_data_export', 'approve_data_export',
        'request_data_deletion',
        'view_transactions', 'create_transactions', 'update_transactions', 'delete_transactions'
      ]},
      
      // admin_readonly
      { role: 'admin_readonly', permissions: [
        'view_users', 'view_permissions', 'view_audit_logs', 'view_settings',
        'view_transactions'
      ]},
      
      // auditor
      { role: 'auditor', permissions: [
        'view_users', 'view_audit_logs', 'export_audit_logs', 'view_transactions'
      ]},
      
      // support
      { role: 'support', permissions: [
        'view_users', 'view_transactions'
      ]},
      
      // CUSTOMER (regular user)
      { role: 'CUSTOMER', permissions: [
        'view_transactions', 'create_transactions', 'update_transactions', 'delete_transactions',
        'request_data_export', 'request_data_deletion'
      ]},
    ];

    // Insert role permissions
    for (const roleData of rolePermissionsData) {
      const rolePermsToInsert = roleData.permissions
        .map(permName => {
          const permId = permMap.get(permName);
          return permId ? { role: roleData.role, permissionId: permId } : null;
        })
        .filter((item): item is { role: string; permissionId: string } => item !== null);
      
      if (rolePermsToInsert.length > 0) {
        await db.insert(rolePermissions).values(rolePermsToInsert);
      }
    }

    console.log('Default permissions initialized successfully');
  } catch (error) {
    console.error('Error initializing default permissions:', error);
  }
}
