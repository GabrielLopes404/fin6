import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Mail, MessageCircle, Phone, BookOpen, Video, HelpCircle } from "lucide-react";
import { motion } from "framer-motion";
import HelpLayout from "@/components/HelpLayout";

export default function HelpSuportePage() {
  const [, setLocation] = useLocation();

  const supportChannels = [
    {
      icon: Mail,
      title: "Email",
      description: "Envie um email para nossa equipe",
      action: "suporte@lucrei.app",
      response: "Resposta em até 24 horas",
      available: "24/7"
    },
    {
      icon: MessageCircle,
      title: "Chat ao Vivo",
      description: "Converse com nosso time em tempo real",
      action: "Iniciar Chat",
      response: "Resposta imediata",
      available: "Seg-Sex, 9h-18h"
    },
    {
      icon: Phone,
      title: "Telefone",
      description: "Fale diretamente com um especialista",
      action: "+55 (11) 9999-9999",
      response: "Atendimento imediato",
      available: "Seg-Sex, 9h-18h"
    }
  ];

  const resources = [
    {
      icon: BookOpen,
      title: "Guias de Ajuda",
      description: "Documentação completa e tutoriais",
      link: "/app/help/guias"
    },
    {
      icon: Video,
      title: "Videoaulas",
      description: "Aprenda assistindo nossos vídeos",
      link: "/app/help/videoaulas"
    },
    {
      icon: HelpCircle,
      title: "FAQ",
      description: "Perguntas frequentes",
      link: "/app/help/guias"
    }
  ];

  return (
    <HelpLayout>
      <div className="max-w-7xl mx-auto">
        <Button 
          variant="ghost" 
          onClick={() => window.history.back()} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 text-primary">
            Central de Suporte
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Estamos aqui para ajudar você a resolver qualquer problema
          </p>
        </motion.div>

        <div className="mb-16">
          <h2 className="text-2xl font-bold mb-6 text-center">Canais de Atendimento</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {supportChannels.map((channel, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardContent className="p-6 text-center">
                    <div className="h-16 w-16 rounded-full bg-gradient-to-r from-primary to-primary/90 flex items-center justify-center mx-auto mb-4">
                      <channel.icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2">{channel.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{channel.description}</p>
                    <div className="mb-4">
                      <p className="font-mono text-sm text-primary mb-1">{channel.action}</p>
                      <p className="text-xs text-muted-foreground">{channel.response}</p>
                      <p className="text-xs text-muted-foreground">{channel.available}</p>
                    </div>
                    <Button 
                      className="w-full"
                      onClick={() => {
                        if (channel.title === "Email") {
                          window.location.href = `mailto:${channel.action}`;
                        } else {
                          setLocation("/contato");
                        }
                      }}
                    >
                      {channel.title === "Chat ao Vivo" ? channel.action : `Usar ${channel.title}`}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-bold mb-6 text-center">Recursos de Auto-Ajuda</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {resources.map((resource, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setLocation(resource.link)}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-primary to-primary/90 flex items-center justify-center flex-shrink-0">
                        <resource.icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg mb-1">{resource.title}</h3>
                        <p className="text-sm text-muted-foreground">{resource.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <Card className="bg-gradient-to-r from-primary/10 to-primary/20 border-primary/20">
            <CardContent className="p-8">
              <div className="text-center">
                <h2 className="text-2xl font-bold mb-4">Suporte Premium 24/7</h2>
                <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                  Clientes dos planos Professional e Enterprise têm acesso a suporte prioritário 
                  24 horas por dia, 7 dias por semana, com tempo de resposta garantido.
                </p>
                <Button 
                  size="lg"
                  onClick={() => setLocation("/pricing")}
                  variant="outline"
                >
                  Conhecer Planos Premium
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </HelpLayout>
  );
}
