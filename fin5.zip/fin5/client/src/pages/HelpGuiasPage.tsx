import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, BookOpen, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import HelpLayout from "@/components/HelpLayout";

export default function HelpGuiasPage() {
  const [, setLocation] = useLocation();

  const guides = [
    {
      category: "Começando",
      items: [
        "Como criar sua primeira conta",
        "Configuração inicial da empresa",
        "Importando dados de outros sistemas",
        "Primeiros passos com o dashboard"
      ]
    },
    {
      category: "Gestão de Clientes",
      items: [
        "Cadastrando novos clientes",
        "Organizando informações de contato",
        "Segmentação e filtros avançados",
        "Exportação de dados de clientes"
      ]
    },
    {
      category: "Faturamento",
      items: [
        "Criando sua primeira fatura",
        "Modelos e templates de faturas",
        "Envio automático por email",
        "Acompanhamento de pagamentos"
      ]
    },
    {
      category: "Transações",
      items: [
        "Registrando receitas e despesas",
        "Categorização automática",
        "Anexando comprovantes",
        "Conciliação bancária"
      ]
    },
    {
      category: "Relatórios",
      items: [
        "Relatório de fluxo de caixa",
        "DRE (Demonstração de Resultado)",
        "Análise de lucratividade",
        "Exportação para Excel/PDF"
      ]
    },
    {
      category: "Segurança",
      items: [
        "Configurando autenticação em dois fatores",
        "Gerenciando permissões de usuários",
        "Auditoria de atividades",
        "Backup e recuperação de dados"
      ]
    }
  ];

  return (
    <HelpLayout>
      <div className="max-w-7xl mx-auto">
        <Button 
          variant="ghost" 
          onClick={() => window.history.back()} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 text-primary">
            Guias de Ajuda
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Documentação completa e passo a passo para usar o LUCREI
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {guides.map((guide, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-primary to-primary/90 flex items-center justify-center">
                      <BookOpen className="h-5 w-5 text-white" />
                    </div>
                    <h2 className="text-xl font-bold">{guide.category}</h2>
                  </div>
                  <ul className="space-y-2">
                    {guide.items.map((item, itemIndex) => (
                      <li
                        key={itemIndex}
                        className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground cursor-pointer transition-colors group"
                      >
                        <ChevronRight className="h-4 w-4 text-primary group-hover:translate-x-1 transition-transform" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-16"
        >
          <Card className="bg-gradient-to-r from-primary/10 to-primary/20 border-primary/20">
            <CardContent className="p-8 text-center">
              <h2 className="text-2xl font-bold mb-4">Não encontrou o que procura?</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Nossa equipe de suporte está pronta para ajudar você
              </p>
              <div className="flex gap-4 justify-center flex-wrap">
                <Button 
                  variant="outline"
                  onClick={() => setLocation("/app/help/videoaulas")}
                >
                  Ver Videoaulas
                </Button>
                <Button 
                  onClick={() => setLocation("/contato")}
                >
                  Falar com Suporte
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </HelpLayout>
  );
}
