import type { ErrorInfo } from "react";

export function logError(error: Error, errorInfo: ErrorInfo) {
  if (process.env.NODE_ENV === "development") {
    console.error("Error caught by boundary:", error);
    console.error("Component stack:", errorInfo?.componentStack);
  }

  const errorData = {
    message: error.message,
    stack: error.stack,
    componentStack: errorInfo?.componentStack || undefined,
    timestamp: new Date().toISOString(),
    userAgent: navigator.userAgent,
    url: window.location.href,
  };

  try {
    fetch("/api/errors/log", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-Token": getCsrfToken(),
      },
      body: JSON.stringify(errorData),
    }).catch((err) => {
      console.error("Failed to log error to server:", err);
    });
  } catch (e) {
    console.error("Failed to send error log:", e);
  }
}

function getCsrfToken(): string {
  const cookies = document.cookie.split(';');
  for (const cookie of cookies) {
    const [name, value] = cookie.trim().split('=');
    if (name === '_csrf') {
      return decodeURIComponent(value);
    }
  }
  return '';
}
