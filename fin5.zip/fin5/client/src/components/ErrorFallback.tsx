import { AlertTriangle, RefreshCw, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";

interface ErrorFallbackProps {
  error: Error;
  resetErrorBoundary: () => void;
}

export function ErrorFallback({ error, resetErrorBoundary }: ErrorFallbackProps) {
  const [, navigate] = useLocation();

  const handleGoHome = () => {
    navigate("/");
    resetErrorBoundary();
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-background to-muted">
      <Card className="w-full max-w-lg shadow-lg">
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 rounded-full bg-destructive/10">
              <AlertTriangle className="w-6 h-6 text-destructive" />
            </div>
            <div>
              <CardTitle className="text-2xl">Algo deu errado</CardTitle>
              <CardDescription>Ocorreu um erro inesperado no sistema</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 rounded-lg bg-muted/50 border border-border">
            <p className="text-sm font-mono text-muted-foreground break-all">
              {error.message || "Erro desconhecido"}
            </p>
          </div>

          {process.env.NODE_ENV === "development" && error.stack && (
            <details className="text-xs">
              <summary className="cursor-pointer text-muted-foreground hover:text-foreground">
                Ver detalhes técnicos
              </summary>
              <pre className="mt-2 p-3 rounded bg-muted/30 overflow-auto max-h-40 text-xs font-mono">
                {error.stack}
              </pre>
            </details>
          )}

          <div className="flex gap-3">
            <Button onClick={resetErrorBoundary} className="flex-1 gap-2">
              <RefreshCw className="w-4 h-4" />
              Tentar novamente
            </Button>
            <Button onClick={handleGoHome} variant="outline" className="flex-1 gap-2">
              <Home className="w-4 h-4" />
              Ir para Home
            </Button>
          </div>

          <p className="text-xs text-center text-muted-foreground">
            Se o problema persistir, entre em contato com o suporte.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

export function RouteErrorFallback({ error, resetErrorBoundary }: ErrorFallbackProps) {
  return (
    <div className="container mx-auto p-8">
      <Card className="shadow-md">
        <CardHeader>
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-destructive" />
            <div>
              <CardTitle>Erro ao carregar página</CardTitle>
              <CardDescription>Ocorreu um erro ao carregar esta página</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-3 rounded-lg bg-muted/50 border">
            <p className="text-sm text-muted-foreground">{error.message}</p>
          </div>
          <Button onClick={resetErrorBoundary} className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Recarregar página
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
