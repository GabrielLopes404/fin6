import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, LayoutDashboard, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface HelpLayoutProps {
  children: React.ReactNode;
}

export default function HelpLayout({ children }: HelpLayoutProps) {
  const [, setLocation] = useLocation();
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setLocation(isAuthenticated ? "/app/dashboard" : "/")}
              className="flex items-center gap-2 font-bold text-xl bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent hover:from-primary/80 hover:to-primary/50 transition-all"
            >
              LUCREI
            </button>
          </div>
          <div className="flex items-center gap-2">
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            ) : isAuthenticated ? (
              <Button 
                variant="default" 
                size="sm"
                onClick={() => setLocation("/app/dashboard")}
              >
                <LayoutDashboard className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            ) : (
              <>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setLocation("/")}
                >
                  <Home className="h-4 w-4 mr-2" />
                  Início
                </Button>
                <Button 
                  variant="default" 
                  size="sm"
                  onClick={() => setLocation("/login")}
                >
                  Entrar
                </Button>
              </>
            )}
          </div>
        </div>
      </header>
      <main className="container py-6 md:py-10">
        {children}
      </main>
      <footer className="border-t py-6 md:py-8">
        <div className="container text-center text-sm text-muted-foreground">
          <p>© 2024 LUCREI. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
