import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Sparkles, type LucideIcon } from "lucide-react";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

export interface PlanCardProps {
  name: string;
  planId: string;
  icon: LucideIcon;
  description: string;
  monthlyPrice: number | null;
  annualPrice: number | null;
  customPrice?: boolean;
  popular?: boolean;
  features: string[];
  cta: string;
  gradient: string;
  glowColor: string;
  annual: boolean;
  index: number;
  onSubscribe?: (planId: string, annual: boolean) => void;
}

export default function PlanCard({
  name,
  planId,
  icon: Icon,
  description,
  monthlyPrice,
  annualPrice,
  customPrice,
  popular,
  features,
  cta,
  gradient,
  glowColor,
  annual,
  index,
  onSubscribe,
}: PlanCardProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const handleSubscribe = () => {
    if (onSubscribe) {
      onSubscribe(planId, annual);
    }
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60, rotateX: -10 }}
      animate={isInView ? { opacity: 1, y: 0, rotateX: 0 } : {}}
      transition={{
        delay: 0.2 + index * 0.15,
        duration: 0.8,
        type: "spring",
        stiffness: 100,
      }}
      whileHover={{ y: -16, scale: 1.03 }}
      style={{ transformStyle: "preserve-3d", perspective: "1000px" }}
      className="relative"
    >
      <Card
        className={`p-10 relative h-full backdrop-blur-xl transition-all duration-500 overflow-hidden ${
          popular
            ? "border-2 border-violet-500/50 bg-gradient-to-br from-violet-500/10 via-fuchsia-500/5 to-background shadow-2xl"
            : "border border-border/50 bg-gradient-to-br from-background/80 to-background/40 hover:border-violet-500/30 shadow-xl"
        }`}
        data-testid={`card-pricing-${index}`}
      >
        {popular && (
          <>
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, type: "spring" }}
              className="absolute -top-5 left-0 right-0 flex justify-center"
            >
              <Badge
                className="bg-gradient-to-r from-violet-600 via-fuchsia-600 to-violet-600 border-0 shadow-2xl px-6 py-2 text-sm font-bold whitespace-nowrap"
                data-testid="badge-popular"
              >
                <Sparkles className="h-4 w-4 mr-2 inline" />
                MAIS POPULAR 🔥
              </Badge>
            </motion.div>

            <motion.div
              className={`absolute -inset-1 bg-gradient-to-r ${gradient} rounded-lg blur-xl opacity-30`}
              animate={{
                opacity: [0.3, 0.5, 0.3],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </>
        )}

        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100"
          animate={{
            x: ["-200%", "200%"],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatDelay: 3,
            ease: "linear",
          }}
        />

        <div className="relative z-10 space-y-8">
          <div className="space-y-4">
            <motion.div
              whileHover={{ scale: 1.1, rotate: 5 }}
              transition={{ type: "spring", stiffness: 300 }}
              className={`h-16 w-16 rounded-2xl bg-gradient-to-br ${gradient} p-0.5 shadow-2xl`}
              style={{ boxShadow: `0 10px 40px ${glowColor}` }}
            >
              <div className="h-full w-full rounded-2xl bg-background/90 backdrop-blur-xl flex items-center justify-center">
                <Icon className="h-8 w-8 text-foreground" />
              </div>
            </motion.div>

            <div>
              <h3
                className="text-3xl font-bold mb-2"
                data-testid={`text-plan-name-${index}`}
              >
                {name}
              </h3>
              <p
                className="text-muted-foreground"
                data-testid={`text-plan-description-${index}`}
              >
                {description}
              </p>
            </div>
          </div>

          <motion.div
            key={annual ? "annual" : "monthly"}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            {customPrice ? (
              <div className="space-y-1">
                <div className="flex items-baseline gap-2">
                  <span className="text-lg text-muted-foreground">
                    A partir de
                  </span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span
                    className={`text-5xl font-bold font-mono tabular-nums bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}
                    data-testid={`text-plan-price-${index}`}
                  >
                    R$ {monthlyPrice}
                  </span>
                  <span className="text-lg text-muted-foreground">/mês</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  Preço personalizado conforme necessidades
                </p>
              </div>
            ) : monthlyPrice ? (
              <>
                <div className="flex items-baseline gap-2">
                  <span
                    className={`text-5xl font-bold font-mono tabular-nums ${
                      popular
                        ? `bg-gradient-to-r ${gradient} bg-clip-text text-transparent`
                        : ""
                    }`}
                    data-testid={`text-plan-price-${index}`}
                  >
                    R$ {annual && annualPrice ? annualPrice : monthlyPrice}
                  </span>
                  <span className="text-lg text-muted-foreground">
                    /{annual && annualPrice ? "ano" : "mês"}
                  </span>
                </div>
                {annual && annualPrice && (
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-sm text-muted-foreground mt-2"
                  >
                    R$ {Math.round(annualPrice / 12)}/mês quando cobrado
                    anualmente
                  </motion.p>
                )}
                {!annual && (
                  <p className="text-sm text-muted-foreground mt-2">
                    ou R$ {annualPrice}/ano
                  </p>
                )}
              </>
            ) : (
              <div
                className={`text-4xl font-bold bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}
                data-testid={`text-plan-price-${index}`}
              >
                Personalizado
              </div>
            )}
          </motion.div>

          <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
            <Button
              onClick={handleSubscribe}
              className={`w-full py-6 text-base font-semibold relative overflow-hidden ${
                popular
                  ? `bg-gradient-to-r ${gradient} shadow-2xl hover:shadow-violet-500/50`
                  : "border-2 hover:border-violet-500/50"
              }`}
              variant={popular ? "default" : "outline"}
              data-testid={`button-plan-cta-${index}`}
            >
              {popular && (
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                  animate={{ x: ["-200%", "200%"] }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "linear",
                    repeatDelay: 1,
                  }}
                />
              )}
              <span className="relative z-10">{cta}</span>
            </Button>
          </motion.div>

          <div className="space-y-4 pt-4 border-t border-border/50">
            {features.map((feature, featureIndex) => (
              <motion.div
                key={featureIndex}
                initial={{ opacity: 0, x: -10 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{
                  delay: 0.5 + index * 0.1 + featureIndex * 0.05,
                }}
                whileHover={{ x: 5 }}
                className="flex items-start gap-3 group/feature"
                data-testid={`text-plan-feature-${index}-${featureIndex}`}
              >
                <motion.div
                  whileHover={{ scale: 1.3, rotate: 360 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <div
                    className={`h-6 w-6 rounded-lg bg-gradient-to-br ${gradient} flex items-center justify-center shadow-lg`}
                  >
                    <Check className="h-4 w-4 text-white" strokeWidth={3} />
                  </div>
                </motion.div>
                <span className="text-base group-hover/feature:text-foreground transition-colors font-medium">
                  {feature}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
